library(testthat)
library(ok)

test_check("ok")
