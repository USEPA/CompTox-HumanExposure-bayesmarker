# can access nickname

    Code
      version$nickname
    Output
      [1] "Shake and Throw"

