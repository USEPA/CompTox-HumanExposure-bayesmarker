#' @keywords internal
#' @import fs
#' @import rlang
"_PACKAGE"

## usethis namespace: start
#' @importFrom glue glue glue_collapse glue_data
#' @importFrom lifecycle deprecated
#' @importFrom purrr map map_chr map_lgl map_int
## usethis namespace: end
NULL
