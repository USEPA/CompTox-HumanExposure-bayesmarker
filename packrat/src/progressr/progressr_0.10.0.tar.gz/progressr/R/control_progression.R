control_progression <- function(type = "shutdown", ...) {
  progression(type = type, ..., class = "control_progression")  
}
